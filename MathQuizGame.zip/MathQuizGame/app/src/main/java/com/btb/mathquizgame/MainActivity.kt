package com.btb.mathquizgame

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var mainMenu: LinearLayout
    private lateinit var quizForm: LinearLayout
    private lateinit var number1: EditText
    private lateinit var number2: EditText
    private lateinit var resultText: TextView
    private lateinit var operationSymbol: TextView
    private lateinit var calculateButton: Button
    private lateinit var goBackButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mainMenu = findViewById(R.id.mainMenu)
        quizForm = findViewById(R.id.quizForm)
        number1 = findViewById(R.id.number1)
        number2 = findViewById(R.id.number2)
        resultText = findViewById(R.id.resultText)
        operationSymbol = findViewById(R.id.operationSymbol)
        calculateButton = findViewById(R.id.calculateButton)
        goBackButton = findViewById(R.id.btnGoBack)

        findViewById<Button>(R.id.btnAddition).setOnClickListener { startQuiz("addition") }
        findViewById<Button>(R.id.btnSubtraction).setOnClickListener { startQuiz("subtraction") }
        findViewById<Button>(R.id.btnMultiplication).setOnClickListener { startQuiz("multiplication") }
        findViewById<Button>(R.id.btnDivision).setOnClickListener { startQuiz("division") }

        calculateButton.setOnClickListener { calculateResult() }
        goBackButton.setOnClickListener { goBackToMainMenu(it) }
    }

    private fun startQuiz(operation: String) {
        mainMenu.visibility = View.GONE
        quizForm.visibility = View.VISIBLE

        operationSymbol.text = when (operation) {
            "addition" -> "+"
            "subtraction" -> "-"
            "multiplication" -> "*"
            "division" -> "/"
            else -> ""
        }

        quizForm.tag = operation
    }

    private fun calculateResult() {
        val num1 = number1.text.toString().toDoubleOrNull()
        val num2 = number2.text.toString().toDoubleOrNull()

        if (num1 != null && num2 != null) {
            val result = when (quizForm.tag) {
                "addition" -> num1 + num2
                "subtraction" -> num1 - num2
                "multiplication" -> num1 * num2
                "division" -> if (num2 != 0.0) num1 / num2 else "Error: Division by zero"
                else -> "Invalid operation"
            }
            resultText.text = result.toString()
        } else {
            resultText.text = "Please enter valid numbers"
        }
    }

    fun goBackToMainMenu(view: View) {
        quizForm.visibility = View.GONE
        mainMenu.visibility = View.VISIBLE
    }
}
